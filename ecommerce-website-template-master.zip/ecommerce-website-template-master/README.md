# E-commerce website template
A simple webpage template for a e-commerce website using html, bootstrap and javascript for front end. PHP and mySQL have been used for backend
